  let slideIndex =0;
  const images =document.querySelectorAll(".gallery img");
  function openSlideshow(index){
    slideIndex = index;
    const slideshow = document.getElementById('slideshow');
    const slideImage =document.getElementById('slideImage');
    slideImage.src = images[slideIndex].src;
    slideshow.style.display = "block";
  }
  function closeSlideshow(){
    document.getElementById('slideshow').style.display = "none";
  }
  function changeSlide(n){
    slideIndex +=n;
    if(slideIndex>=images.length)slideIndex = 0;
    if (slideIndex<0)slideIndex = images.length-1;
    const slideImage =document.getElementById('slideImage');
    slideImage.src=images[slideIndex].src;
  }
//Optional:Keyboard navigation
document.addEventListener('keydown',function(event){
    if (document.getElementById('slideshow').style.display === 'block'){
        if (event.key==='ArrowLeft')changeSlide(-1);
        if(event.key==='ArrowRight')changeSlide(1);
         if(event.key==='Escape')closeSlideshow();
    }
});